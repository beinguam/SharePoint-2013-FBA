using System;
using System.Web.Security;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Utilities;
using System.Web.UI.WebControls;
using System.Web;
//BK added so that code can create List type
using System.Collections.Generic;

namespace Visigo.Sharepoint.FormsBasedAuthentication
{
    /// <summary>
    /// Code behind for UserEdit.aspx
    /// </summary>
    public partial class UserEdit : LayoutsPageBase
    {
        // BK added line below to create global variables for use in the elevated code
        string url = null;

        private bool _showRoles;

        protected override bool RequireSiteAdministrator
        {
            //BK changed the code below to say 'false' so that Site Collection Administrator is not needed
            get { return false; }
        }

        // BK added code below to only require users with Design Permissions or higher (ie. Project Administrators) to add and update external users 
        protected override SPBasePermissions RightsRequired
        {
            get
            {
                SPBasePermissions permissions = base.RightsRequired
                    | SPBasePermissions.ViewPages
                    | SPBasePermissions.ApplyStyleSheets;
                return permissions;
            }
        }
        // BK added code above

        protected override void OnLoad(EventArgs e)
        {
            this.CheckRights();

            // init
            _showRoles = (new MembershipSettings(SPContext.Current.Web)).EnableRoles;

            // get user info
            string userName = this.Request.QueryString["USERNAME"];
            SPUser spuser = null;
            try
            {
                spuser = this.Web.AllUsers[Utils.EncodeUsername(userName)];
            }
            catch
            {
                
            }
            MembershipUser user = Utils.BaseMembershipProvider().GetUser(userName,false);

            if (user != null)
            {
                if (!Page.IsPostBack)
                {
                    // load user props
                    if (spuser != null)
                    {
                        txtEmail.Text = spuser.Email;
                        txtFullName.Text = spuser.Name;
                    }
                    else
                    {
                        txtEmail.Text = user.Email;
                        txtFullName.Text = user.UserName;
                    }
                    txtUsername.Text = user.UserName;
                    isActive.Checked = user.IsApproved;
                    isLocked.Checked = user.IsLockedOut;
                    isLocked.Enabled = user.IsLockedOut;

                    // if roles activated display roles
                    if (_showRoles)
                    {
                        RolesSection.Visible = true;
                        GroupSection.Visible = false;

                        try
                        {
                            // load roles
                            string[] roles = Utils.BaseRoleProvider().GetAllRoles();
                            rolesList.DataSource = roles;
                            rolesList.DataBind();

                            // select roles associated with the user
                            for (int i = 0; i < roles.Length; i++)
                            {
                                ListItem item = rolesList.Items.FindByText(roles[i].ToString());
                                if (item != null) item.Selected = Utils.BaseRoleProvider().IsUserInRole(user.UserName, roles[i].ToString());
                            }
                        }
                        catch (Exception ex)
                        {
                            Utils.LogError(ex, true);
                        }
                    }
                    // otherwise display groups
                    else 
                    {
                        GroupSection.Visible = true;
                        RolesSection.Visible = false;

                        try
                        {
                            // load groups
                            //BK added lines below
                            SPGroupCollection extranetgroup = null;
                            //Create a string array to contain the group names (an array is needed because GetCollection requires an array input)
                            string[] groupnamearray = null;
                            //Create a list type to contain the group names temporarily 
                            var templist = new List<string>();
                            //Create an integer to contain the index number of all the group names
                            int groupnamearrayindex = -1;
                            string groupname = null;
                            bool externalgroupexists = false;

                            // load groups
                            //BK added code below to iterate through all the groups in the Site Collection                       
                            for (int i = 0; i < this.Web.SiteGroups.Count; i++)
                            {
                                SPGroup group = this.Web.SiteGroups[i];
                                groupname = "";
                                groupname = group.Name;
                                //Convert group name to lowercase for matching
                                groupname = groupname.ToLower();

                                //Adds group to templist if name of the group is for external users                            
                                if (groupname.Contains("external") && groupname.Contains("non") && groupname.Contains("employee"))
                                {
                                    //Increment groupnamearrayindex for use in iterating through group names to automatically check them
                                    groupnamearrayindex++;
                                    //Add external group to templist
                                    templist.Add(group.Name);
                                    externalgroupexists = true;
                                }
                            }
                            if (externalgroupexists == true)
                            {
                                //Convert templist to groupnamearray array
                                groupnamearray = templist.ToArray();
                                extranetgroup = this.Web.SiteGroups.GetCollection(groupnamearray);
                                //Using the SPGroupCollection extranetgroup as a data source, bind to the SharePoint:InputFormCheckBoxList control
                                groupList.DataSource = extranetgroup;
                                groupList.DataBind();                                
                            }
                            else
                            {
                                //If external group does not exist then have the group section not display
                                GroupSection.Visible = false;
                            }
                            //BK added code above

                            //BK commented out the lines below because code is not needed any longer (as it was the original code)
                            //groupList.DataSource = this.Web.SiteGroups;
                            //groupList.DataBind();

                            if (spuser != null)
                            {
                                // select groups associated with the user
                                foreach (SPGroup group in spuser.Groups)
                                {
                                    ListItem item = groupList.Items.FindByText(group.Name);
                                    if (item != null) item.Selected = true;
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            Utils.LogError(ex, true);
                        }
                    }
                }
            }
            else
            {
                SPUtility.TransferToErrorPage(LocalizedString.GetGlobalString("FBAPackWebPages", "UserNotFound"));
            }
        }

        protected void OnSubmit(object sender, EventArgs e)
        {
            // BK added code below to set global variables for use in the elevated code
            url = SPContext.Current.Web.Url;
            // BK added code below to run code as a Site Collection Administrator
            SPSecurity.RunWithElevatedPrivileges(delegate(){
            //Need to get SPSite object using elevated user
            SPSite mySite = new SPSite(url);
            SPWeb myWeb = mySite.OpenWeb();
            //Need to allow unsafe updates to list since the logined user does not have access
            myWeb.AllowUnsafeUpdates = true;
            // BK added code above

            // get user info
            string userName = this.Request.QueryString["USERNAME"];
            SPUser spuser = null;
            // This could be done with EnsureUsers, which won't throw an exception if the user hasn't logged on to the site.
            try
            {
                //spuser = this.Web.AllUsers[Utils.EncodeUsername(userName)];
                //BK commented out line above and added line below
                spuser = myWeb.AllUsers[Utils.EncodeUsername(userName)];
            }
            catch
            {

            }
            MembershipUser user = Utils.BaseMembershipProvider().GetUser(userName,false);
            
            // check user exists
            if (user != null)
            {
                try
                {
                    // TODO: If we want the Email to be used for the user account, we need to delete the user and create a new one with the new email address.
                    // This will mean we need to iterate over the groups that the user is a member of, in all site collections in all web apps, and add the new user
                    // to those groups.  In the meantime, we allow the email to be changed, but this won't update the account username.

                    // update membership provider info
                    user.Email = txtEmail.Text;
                    user.IsApproved = isActive.Checked;

                    //Unlock Account
                    if (user.IsLockedOut && !isLocked.Checked)
                    {
                        user.UnlockUser();
                    }
                    try
                    {
                        Utils.BaseMembershipProvider().UpdateUser(user);
                    }
                    catch (System.Configuration.Provider.ProviderException ex)
                    {
                        lblMessage.Text = ex.Message;
                        return;
                    }

                    // if roles enabled add/remove user to selected role(s)
                    if (_showRoles)
                    {
                        for (int i = 0; i < rolesList.Items.Count; i++)
                        {
                            if (rolesList.Items[i].Selected)
                            {
                                if (!Utils.BaseRoleProvider().IsUserInRole(user.UserName, rolesList.Items[i].Value))
                                    Utils.BaseRoleProvider().AddUsersToRoles(new string[] {user.UserName}, new string[] {rolesList.Items[i].Value});
                            }
                            else
                            {
                                if (Utils.BaseRoleProvider().IsUserInRole(user.UserName, rolesList.Items[i].Value))
                                    Utils.BaseRoleProvider().RemoveUsersFromRoles(new string[] {user.UserName}, new string[] {rolesList.Items[i].Value});
                            }
                        }
                    }
                    // or add/remove user to selected group(s)
                    else
                    {
                        for (int i = 0; i < groupList.Items.Count; i++)
                        {
                            string groupName = groupList.Items[i].Value;

                            // determine whether user is in group
                            bool userInGroup = false;

                            if (spuser != null)
                            {
                                foreach (SPGroup group in spuser.Groups)
                                {
                                    if (group.Name == groupName)
                                    {
                                        userInGroup = true;
                                        break;
                                    }
                                }
                            }

                            // if selected add user to group
                            if (groupList.Items[i].Selected)
                            {
                                // only add if not already in group
                                if (!userInGroup)
                                {
                                    //Add the user to SharePoint if they're not already a SharePoint user
                                    if (spuser == null)
                                    {
                                        try
                                        {
                                            //spuser = this.Web.EnsureUser(Utils.EncodeUsername(userName));
                                            //BK commented out line above and added line below
                                            spuser = myWeb.EnsureUser(Utils.EncodeUsername(userName));
                                        }
                                        catch (Exception ex)
                                        {
                                            lblMessage.Text = LocalizedString.GetGlobalString("FBAPackWebPages", "ErrorAddingToSharePoint");
                                            Utils.LogError(ex, false);
                                            return;
                                        }
                                    }                                    
                                    //this.Web.SiteGroups[groupName].AddUser(spuser);
                                    //BK commented out line above and added line below
                                    myWeb.SiteGroups[groupName].AddUser(spuser);

                                }
                            }
                            // else remove user from group
                            else
                            {
                                // only attempt remove if actually in the group
                                if (userInGroup)
                                    //this.Web.SiteGroups[groupName].RemoveUser(spuser);
                                   //BK commented out line above and added line below
                                    myWeb.SiteGroups[groupName].RemoveUser(spuser);
                            }
                        }
                    }
                    
                    // update sharepoint user info
                    if (spuser != null)
                    {
                        spuser.Email = txtEmail.Text;
                        spuser.Name = txtFullName.Text;
                        spuser.Update();
                    }
                    
                    //BK added this code below to create SharePoint user for external user if it deosn't exist
                    else if (spuser == null)
                    {
                        myWeb.AllUsers.Add(Utils.EncodeUsername(user.UserName), user.Email, txtFullName.Text, "");
                    }
                    // BK added code above

                    SPUtility.Redirect("FBA/Management/UsersDisp.aspx", SPRedirectFlags.RelativeToLayoutsPage | SPRedirectFlags.UseSource, this.Context);
                    
                }
                catch (Exception ex)
                {
                    Utils.LogError(ex, true);
                }
            }
            else
            {
                SPUtility.TransferToErrorPage(LocalizedString.GetGlobalString("FBAPackWebPages","UserNotFound"));
            }
            // BK added line below
            });
        }

        protected void OnResetPassword(object sender, EventArgs e)
        {
            SPUtility.Redirect(string.Format("FBA/Management/UserResetPassword.aspx?UserName={0}&Source={1}", this.Request.QueryString["USERNAME"], SPHttpUtility.UrlKeyValueEncode(SPUtility.OriginalServerRelativeRequestUrl)), SPRedirectFlags.RelativeToLayoutsPage, this.Context);
        }

        protected void OnDeleteUser(object sender, EventArgs e)
        {
            SPUtility.Redirect(string.Format("FBA/Management/UserDelete.aspx?UserName={0}&Source={1}", this.Request.QueryString["USERNAME"], SPHttpUtility.UrlKeyValueEncode(SPUtility.OriginalServerRelativeRequestUrl)), SPRedirectFlags.RelativeToLayoutsPage, this.Context);
        }
    }
}
