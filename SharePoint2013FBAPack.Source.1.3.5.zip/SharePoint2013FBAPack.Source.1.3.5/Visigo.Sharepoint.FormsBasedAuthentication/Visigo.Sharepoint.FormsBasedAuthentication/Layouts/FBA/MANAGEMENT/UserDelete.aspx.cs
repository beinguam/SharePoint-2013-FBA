using System;
using System.Web.Security;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.WebControls;
using System.Web.UI.WebControls;
using System.Web;
using System.Globalization;

namespace Visigo.Sharepoint.FormsBasedAuthentication
{
    /// <summary>
    /// Code behind for UserDelete.aspx
    /// </summary>
    public partial class UserDelete : LayoutsPageBase
    {
        //BK added line below to create global variables for use in the elevated code
        string websiteurl = null;

        protected override bool RequireSiteAdministrator
        {
            //BK changed the code below to say 'false' so that Site Collection Administrator is not needed
            get { return false; }
        }

        // BK added code below to only require users with Design Permissions or higher (ie. Project Administrators) to add and update external users 
        protected override SPBasePermissions RightsRequired
        {
            get
            {
                SPBasePermissions permissions = base.RightsRequired
                    | SPBasePermissions.ViewPages
                    | SPBasePermissions.ApplyStyleSheets;
                return permissions;
            }
        }
        // BK added code above

        protected override void OnLoad(EventArgs e)
        {
            this.CheckRights();
        
            // display error confirmation message
            string userName = Request.QueryString["USERNAME"];
            if (!string.IsNullOrEmpty(userName))
            {
                deleteMsg.Text = string.Format(localizedMsg.Text, userName);
            }
            else
            {
                SPUtility.TransferToErrorPage(LocalizedString.GetGlobalString("FBAPackWebPages", "UserNotFound"));
            }
        }

        protected void OnDelete(object sender, EventArgs e)
        {
            // BK added code below to set global variables for use in the elevated code
            websiteurl = this.Web.Url;
            // BK added code below to run code as a Site Collection Administrator
            SPSecurity.RunWithElevatedPrivileges(delegate(){
            //Need to get SPSite object using elevated user
	        SPSite mySite = new SPSite(websiteurl);
	        SPWeb myWeb = mySite.OpenWeb();
            //Need to allow unsafe updates to list since the logined user does not have access
	        myWeb.AllowUnsafeUpdates = true;

            string userName = Request.QueryString["USERNAME"];

            try
            {
                // delete user from FBA data store
                Utils.BaseMembershipProvider().DeleteUser(userName,true);

                // delete user from SharePoint            
                try
                {
                    //this.Web.SiteUsers.Remove(Utils.EncodeUsername(userName));
                    //this.Web.Update();
                    //BK commented out lines above and added lines below
                    myWeb.SiteUsers.Remove(Utils.EncodeUsername(userName));
                    myWeb.Update();
                }
                catch
                {
                    //left Empty because the user might not be in the SharePoint site yet.
                }
            }
            catch (Exception ex)
            {
                Utils.LogError(ex, true);                
            }
            
            //Redirect to UsersDisp or Source, as long as source is not UserEdit.aspx - as that will no longer work as the user is deleted
            string url = "FBA/Management/UsersDisp.aspx";

            SPUtility.DetermineRedirectUrl(url, SPRedirectFlags.RelativeToLayoutsPage | SPRedirectFlags.UseSource, this.Context, null, out url);

            if (url.ToLower().Contains("useredit.aspx"))
            {
                url = "FBA/Management/UsersDisp.aspx";

                SPUtility.DetermineRedirectUrl(url, SPRedirectFlags.RelativeToLayoutsPage, this.Context, null, out url);
            }

            SPUtility.Redirect(url, SPRedirectFlags.Default, this.Context);
            });
        }
   
    }
}
