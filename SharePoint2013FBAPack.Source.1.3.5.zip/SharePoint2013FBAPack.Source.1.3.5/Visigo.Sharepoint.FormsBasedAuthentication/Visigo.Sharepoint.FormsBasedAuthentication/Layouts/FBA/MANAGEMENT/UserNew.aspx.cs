using System;
using System.Web.Security;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Administration;
using System.Web.UI.WebControls;
using Microsoft.SharePoint.Utilities;
using System.Web;
//BK added so that code can create List type
using System.Collections.Generic;

namespace Visigo.Sharepoint.FormsBasedAuthentication
{
    /// <summary>
    /// Code behind for UserNew.aspx
    /// </summary>
    public partial class UserNew : LayoutsPageBase
    {
        // BK added 2 lines below to create global variables for use in the elevated code
        MembershipUser user = null;
        string url = null;

        protected override bool RequireSiteAdministrator
        {
            //BK changed the code below to say 'false' so that Site Collection Administrator is not needed
            get { return false; }
        }

        // BK added code below to only require users with Design Permissions or higher (ie. Project Administrators) to add and update external users 
        protected override SPBasePermissions RightsRequired
        {
            get
            {
                SPBasePermissions permissions = base.RightsRequired
                    | SPBasePermissions.ViewPages
                    | SPBasePermissions.ApplyStyleSheets;
                return permissions;
            }
        }
        // BK added code above

        protected override void OnLoad(EventArgs e)
        {
            this.CheckRights();

            bool _showRoles = (new MembershipSettings(SPContext.Current.Web)).EnableRoles;

            ReqValEmailSubject.Enabled = emailUser.Checked;

            if (!Page.IsPostBack)
            {
                try
                {
                    //BK added the line below to hide the Email section
                    EmailSection.Visible = false;                                       
                    
                    // if roles activated display roles
                    if (_showRoles)
                    {
                        RolesSection.Visible = true;
                        GroupSection.Visible = false;

                        // load roles
                        rolesList.DataSource = Utils.BaseRoleProvider().GetAllRoles();
                        rolesList.DataBind();
                    }
                    // otherwise display groups
                    else
                    {
                        GroupSection.Visible = true;
                        RolesSection.Visible = false;

                        //BK added lines below
                        SPGroupCollection extranetgroup = null;
                        //Create a string array to contain the group names (an array is needed because GetCollection requires an array input)
                        string[] groupnamearray = null;
                        //Create a list type to contain the group names temporarily 
                        var templist = new List<string>();
                        //Create an integer to contain the index number of all the group names
                        int groupnamearrayindex = -1;
                        string groupname = null;
                        bool externalgroupexists = false;

                        // load groups
                        //BK added code below to iterate through all the groups in the Site Collection                       
                        for (int i = 0; i < this.Web.SiteGroups.Count; i++)
                        {   
                            SPGroup group = this.Web.SiteGroups[i];                                    
                            groupname = "";
                            groupname = group.Name;
                            //Convert group name to lowercase for matching
                            groupname = groupname.ToLower();

                            //Adds group to templist if name of the group is for external users                            
                            if (groupname.Contains("external") && groupname.Contains("non") && groupname.Contains("employee"))
                            {
                                //Increment groupnamearrayindex for use in iterating through group names to automatically check them
                                groupnamearrayindex++;
                                //Add external group to templist
                                templist.Add(group.Name);                                 
                                externalgroupexists = true;                                                              
                            }                            
                        }
                        if (externalgroupexists == true)
                        {
                            //Convert templist to groupnamearray array
                            groupnamearray = templist.ToArray();
                            extranetgroup = this.Web.SiteGroups.GetCollection(groupnamearray);
                            //Using the SPGroupCollection extranetgroup as a data source, bind to the SharePoint:InputFormCheckBoxList control
                            groupList.DataSource = extranetgroup;
                            groupList.DataBind();
                            //iterate through external group name to check them automatically
                            for (int i = 0; i <= groupnamearrayindex; i++)
                            {
                                //Automatically check the external user group
                                groupList.Items[i].Selected = true;
                            }
                        }
                        else
                        {
                            //If external group does not exist then have the group section not display
                            GroupSection.Visible = false;
                        }
                        //BK added code above
                        
                        //BK commented out the lines below because code is not needed any longer (as it was the original code)
                        //groupList.DataSource = this.Web.SiteGroups;
                        //groupList.DataBind();
                    }

                    // Display Question and answer if required by provider
                    if (Utils.BaseMembershipProvider().RequiresQuestionAndAnswer)
                    {
                        QuestionSection.Visible = true;
                        AnswerSection.Visible = true;
                    }
                    else
                    {
                        QuestionSection.Visible = false;
                        AnswerSection.Visible = false;
                    }
                }
                catch (Exception ex)
                {
                    Utils.LogError(ex, true);
                }
            }
        }

        protected void OnSubmit(object sender, EventArgs e)
        {
            // BK added code below to edit global variables for use in the elevated code            
            url = SPContext.Current.Web.Url;

            // BK added code below to run code as a Site Collection Administrator
            SPSecurity.RunWithElevatedPrivileges(delegate(){
            //Need to get SPSite object using elevated user
            SPSite mySite = new SPSite(url);
            SPWeb myWeb = mySite.OpenWeb();
            // BK added code above

            // ModifiedBySolvion
            // bhi - 09.01.2012
            // Reset message labels
            lblMessage.Text = lblAnswerMessage.Text = lblEmailMessage.Text = lblPasswordMessage.Text = lblQuestionMessage.Text = "";
            // EndModifiedBySolvion

            bool _showRoles = (new MembershipSettings(SPContext.Current.Web)).EnableRoles;

            // check to see if username already in use
            //MembershipUser user = Utils.BaseMembershipProvider().GetUser(txtUsername.Text,false);
            //BK commented out line above and added line below
            user = Utils.BaseMembershipProvider().GetUser(txtUsername.Text,false);
            
            if (user == null)
            {
                try
                {
                    // get site reference             
                    string provider = Utils.GetMembershipProvider(this.Site);

                    // create FBA database user
                    MembershipCreateStatus createStatus;

                    if (Utils.BaseMembershipProvider().RequiresQuestionAndAnswer)
                    {
                        user = Utils.BaseMembershipProvider().CreateUser(txtUsername.Text, txtPassword.Text, txtEmail.Text, txtQuestion.Text, txtAnswer.Text, isActive.Checked, null, out createStatus);
                    }
                    else
                    {
                        user = Utils.BaseMembershipProvider().CreateUser(txtUsername.Text, txtPassword.Text, txtEmail.Text, null, null, isActive.Checked, null, out createStatus);
                    }


                    if (createStatus != MembershipCreateStatus.Success)
                    {
                        SetErrorMessage(createStatus);
                        return;
                    }

                    if (user == null)
                    {
                        lblMessage.Text = LocalizedString.GetGlobalString("FBAPackWebPages", "UnknownError");
                        return;
                    }

                    bool groupAdded = false;

                    if (_showRoles)
                    {
                        for (int i = 0; i < rolesList.Items.Count; i++)
                        {
                            if (rolesList.Items[i].Selected)
                            {
                                Utils.BaseRoleProvider().AddUsersToRoles(new string[] {user.UserName}, new string[] {rolesList.Items[i].Value});
                            }
                        }

                        // add user to SharePoint whether a role was selected or not
                        AddUserToSite(Utils.EncodeUsername(user.UserName), user.Email, txtFullName.Text);
                    }
                    else
                    {
                        // add user to each group that was selected
                        for (int i = 0; i < groupList.Items.Count; i++)
                        {
                            if (groupList.Items[i].Selected)
                            {
                                // add user to group
                                //SPGroup group = this.Web.SiteGroups[groupList.Items[i].Value];
                                //BK commented out line above and added 2 lines below
                                SPGroup group = myWeb.SiteGroups[groupList.Items[i].Value];
                                //BK added - need to allow unsafe updates to list since the logined user does not have access
                                myWeb.AllowUnsafeUpdates = true;

                                group.AddUser(
                                    Utils.EncodeUsername(user.UserName),
                                    user.Email,
                                    txtFullName.Text,
                                    "");

                                // update
                                group.Update();
                                groupAdded = true;                                
                            }
                        }

                        // if no group selected, add to site with no permissions
                        if (!groupAdded)
                        {
                            AddUserToSite(Utils.EncodeUsername(user.UserName), user.Email, txtFullName.Text);
                        }
                    }

                    // Email User
                    if ((emailUser.Checked == true))
                    {
                        //InputFormTextBox txtEmailSubject = (InputFormTextBox)emailUser.FindControl("txtEmailSubject");
                        //InputFormTextBox txtEmailBody = (InputFormTextBox)emailUser.FindControl("txtEmailBody");
                        if ((!string.IsNullOrEmpty(txtEmailSubject.Text)) && (!string.IsNullOrEmpty(txtEmailBody.Text)))
                            Email.SendEmail(this.Web, user.Email, txtEmailSubject.Text, txtEmailBody.Text);
                    }

                    SPUtility.Redirect("FBA/Management/UsersDisp.aspx", SPRedirectFlags.RelativeToLayoutsPage | SPRedirectFlags.UseSource, this.Context);


                }
                catch (Exception ex)
                {
                    Utils.LogError(ex, true);
                }
            }
            else
            {
                lblMessage.Text = LocalizedString.GetGlobalString("FBAPackWebPages", "DuplicateUserName"); ;
            }
// BK added line below to end the elevated code function
            });
        }

        protected void SetErrorMessage(MembershipCreateStatus status)
        {
             switch (status)
             {
                 case MembershipCreateStatus.DuplicateUserName:
                    lblMessage.Text = LocalizedString.GetGlobalString("FBAPackWebPages", "DuplicateUserName");
                    break;

                case MembershipCreateStatus.DuplicateEmail:
                    lblEmailMessage.Text = LocalizedString.GetGlobalString("FBAPackWebPages", "DuplicateEmail");
                    break;

                case MembershipCreateStatus.InvalidPassword:
                    string message = "";
                    if (string.IsNullOrEmpty(Utils.BaseMembershipProvider().PasswordStrengthRegularExpression))
                    {
                        message = string.Format(LocalizedString.GetGlobalString("FBAPackWebPages", "InvalidPasswordChars"), Utils.BaseMembershipProvider().MinRequiredPasswordLength,  Utils.BaseMembershipProvider().MinRequiredNonAlphanumericCharacters);
                    }
                    else
                    {
                        message = string.Format(LocalizedString.GetGlobalString("FBAPackWebPages", "InvalidPasswordCharsRegex"), Utils.BaseMembershipProvider().MinRequiredPasswordLength,  Utils.BaseMembershipProvider().MinRequiredNonAlphanumericCharacters, Utils.BaseMembershipProvider().PasswordStrengthRegularExpression);
                    }
                    //LocalizedString.GetGlobalString("FBAPackWebPages", "InvalidPassword")
                    // TODO: use resource files
                    lblPasswordMessage.Text = message;
                    break;

                case MembershipCreateStatus.InvalidEmail:
                    lblEmailMessage.Text = LocalizedString.GetGlobalString("FBAPackWebPages", "InvalidEmail");
                    break;

                case MembershipCreateStatus.InvalidAnswer:
                    lblAnswerMessage.Text = LocalizedString.GetGlobalString("FBAPackWebPages", "InvalidAnswer");
                    break;

                case MembershipCreateStatus.InvalidQuestion:
                    lblQuestionMessage.Text = LocalizedString.GetGlobalString("FBAPackWebPages", "InvalidQuestion");
                    break;

                case MembershipCreateStatus.InvalidUserName:
                    lblMessage.Text = LocalizedString.GetGlobalString("FBAPackWebPages", "InvalidUserName");
                    break;

                case MembershipCreateStatus.ProviderError:
                    lblMessage.Text = LocalizedString.GetGlobalString("FBAPackWebPages", "ProviderError");
                    break;

                case MembershipCreateStatus.UserRejected:
                    lblMessage.Text = LocalizedString.GetGlobalString("FBAPackWebPages", "UserRejected");
                    break;

                default:
                    lblMessage.Text = LocalizedString.GetGlobalString("FBAPackWebPages", "UnknownError");
                    break;
            }
        }

        /// <summary>
        /// Adds a user to the SharePoint (in no particular group)
        /// </summary>
        /// <param name="login"></param>
        /// <param name="email"></param>
        /// <param name="fullname"></param>
        private void AddUserToSite(string login, string email, string fullname)
        {
            //BK added code below to run code as a Site Collection Administrator
           SPSecurity.RunWithElevatedPrivileges(delegate(){
           //Need to get SPSite object using elevated user
           SPSite mySite = new SPSite(url);
           SPWeb myWeb = mySite.OpenWeb();
           //Need to allow unsafe updates to list since the logined user does not have access
           myWeb.AllowUnsafeUpdates = true;
           //BK added code above
           //this.Web.AllUsers.Add(
           //BK commented out line above and added line below            
           myWeb.AllUsers.Add(
                login,
                email,
                fullname,
                "");
            });
            //BK added line above
        }
    }
}
